
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Cloud, CloudRain, Sun, Wind, Droplets, Thermometer, CloudDrizzle, CloudSnow } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Mock weather data
const mockWeatherData = [
  {
    date: "2025-04-11",
    day: "Today",
    temp: 32,
    tempMin: 25,
    tempMax: 34,
    humidity: 65,
    windSpeed: 12,
    condition: "Clear",
    icon: <Sun className="h-10 w-10 text-yellow-500" />,
    advice: "Ideal day for harvesting. Ensure proper hydration for crops due to high temperatures."
  },
  {
    date: "2025-04-12",
    day: "Tomorrow",
    temp: 30,
    tempMin: 24,
    tempMax: 31,
    humidity: 70,
    windSpeed: 10,
    condition: "Partly Cloudy",
    icon: <Cloud className="h-10 w-10 text-gray-500" />,
    advice: "Good day for applying fertilizers. Moderate temperatures are suitable for most field work."
  },
  {
    date: "2025-04-13",
    day: "Sunday",
    temp: 29,
    tempMin: 23,
    tempMax: 30,
    humidity: 75,
    windSpeed: 15,
    condition: "Light Rain",
    icon: <CloudDrizzle className="h-10 w-10 text-blue-500" />,
    advice: "Light rain expected. Consider postponing pesticide application. Good for seed germination."
  },
  {
    date: "2025-04-14",
    day: "Monday",
    temp: 28,
    tempMin: 22,
    tempMax: 29,
    humidity: 80,
    windSpeed: 18,
    condition: "Rain",
    icon: <CloudRain className="h-10 w-10 text-blue-700" />,
    advice: "Heavy rain expected. Ensure proper drainage in fields. Avoid fertilizer application."
  },
  {
    date: "2025-04-15",
    day: "Tuesday",
    temp: 30,
    tempMin: 24,
    tempMax: 32,
    humidity: 72,
    windSpeed: 8,
    condition: "Cloudy",
    icon: <Cloud className="h-10 w-10 text-gray-500" />,
    advice: "Cloudy conditions. Good day for transplanting seedlings and field preparation."
  }
];

// Indian states for dropdown
const indianStates = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", 
  "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", 
  "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", 
  "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", 
  "Uttarakhand", "West Bengal"
];

const WeatherForecast = () => {
  const [location, setLocation] = useState("");
  const [state, setState] = useState("");
  const [weatherData, setWeatherData] = useState(mockWeatherData);
  const [isSearched, setIsSearched] = useState(false);

  const handleSearch = () => {
    // In a real application, this would fetch weather data from an API
    // For now, we'll just use our mock data and set isSearched to true
    setIsSearched(true);
    // For demonstration, we'll show a location-specific greeting
    console.log(`Searching weather for ${location}, ${state}`);
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return <Sun className="h-10 w-10 text-yellow-500" />;
      case 'partly cloudy':
        return <Cloud className="h-10 w-10 text-gray-500" />;
      case 'cloudy':
        return <Cloud className="h-10 w-10 text-gray-500" />;
      case 'light rain':
        return <CloudDrizzle className="h-10 w-10 text-blue-500" />;
      case 'rain':
        return <CloudRain className="h-10 w-10 text-blue-700" />;
      case 'heavy rain':
        return <CloudRain className="h-10 w-10 text-blue-900" />;
      case 'snow':
        return <CloudSnow className="h-10 w-10 text-blue-200" />;
      default:
        return <Sun className="h-10 w-10 text-yellow-500" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-poppins font-bold text-kisan-primary mb-2">
          Weather Forecast for Farming
        </h1>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Get a 5-day weather forecast tailored for agricultural activities. We provide specific recommendations based on weather conditions.
        </p>
      </div>

      {/* Search Box */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Check Weather For Your Location</CardTitle>
          <CardDescription>
            Enter your location to get a 5-day weather forecast with farming recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <Input
              placeholder="Enter your village/city..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="flex-1"
            />
            <Select value={state} onValueChange={setState}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Select state" />
              </SelectTrigger>
              <SelectContent>
                {indianStates.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              onClick={handleSearch} 
              className="bg-kisan-primary hover:bg-kisan-secondary"
              disabled={!location || !state}
            >
              Get Forecast
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Weather Cards */}
      {isSearched && (
        <>
          <div className="mb-6">
            <h2 className="text-2xl font-poppins font-semibold text-kisan-dark-brown">
              5-Day Weather Forecast for {location}, {state}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            {weatherData.map((day, index) => (
              <Card key={index} className={index === 0 ? "border-kisan-primary" : ""}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{day.day}</CardTitle>
                  <CardDescription>{day.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center mb-2">
                    {day.icon}
                  </div>
                  <div className="text-center mb-2">
                    <p className="text-2xl font-semibold">{day.temp}°C</p>
                    <p className="text-sm text-gray-500">{day.tempMin}° / {day.tempMax}°</p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Droplets className="h-4 w-4 mr-1 text-blue-500" />
                        <span>Humidity</span>
                      </div>
                      <span>{day.humidity}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Wind className="h-4 w-4 mr-1 text-blue-500" />
                        <span>Wind</span>
                      </div>
                      <span>{day.windSpeed} km/h</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Farming Advice Section */}
          <div className="mb-6">
            <h2 className="text-2xl font-poppins font-semibold text-kisan-dark-brown mb-4">
              Farming Recommendations
            </h2>
            <div className="space-y-4">
              {weatherData.map((day, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        {day.icon}
                      </div>
                      <div>
                        <h3 className="font-poppins font-semibold text-lg mb-1">{day.day} - {day.condition}</h3>
                        <p className="text-gray-700">{day.advice}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Seasonal Farming Tips */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Seasonal Farming Tips</CardTitle>
              <CardDescription>
                General recommendations for this time of year in your region
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-kisan-primary mr-2">•</span>
                  <span>Apply organic mulch to conserve soil moisture during the upcoming hot days.</span>
                </li>
                <li className="flex items-start">
                  <span className="text-kisan-primary mr-2">•</span>
                  <span>Consider planting heat-resistant varieties for summer crops.</span>
                </li>
                <li className="flex items-start">
                  <span className="text-kisan-primary mr-2">•</span>
                  <span>Ensure irrigation systems are functioning optimally for the season.</span>
                </li>
                <li className="flex items-start">
                  <span className="text-kisan-primary mr-2">•</span>
                  <span>Monitor for common pests that emerge during this season in your region.</span>
                </li>
                <li className="flex items-start">
                  <span className="text-kisan-primary mr-2">•</span>
                  <span>Prepare for possible rain interruptions in harvesting schedules.</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </>
      )}

      {/* If no location has been searched yet, show a placeholder message */}
      {!isSearched && (
        <div className="text-center py-10">
          <Cloud className="h-16 w-16 text-kisan-primary mx-auto mb-4" />
          <h3 className="text-xl font-poppins font-semibold mb-2">Enter Your Location</h3>
          <p className="text-gray-600 max-w-md mx-auto">
            Search for your location above to view the 5-day weather forecast and get farming recommendations tailored to your area.
          </p>
        </div>
      )}
    </div>
  );
};

export default WeatherForecast;
